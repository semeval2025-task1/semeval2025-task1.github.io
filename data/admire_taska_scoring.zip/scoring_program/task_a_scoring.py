import json
import os
import re
from sys import argv, exit, stdout
from ast import literal_eval
from math import log2
import pandas as pd
import numpy as np
from sklearn.metrics import accuracy_score
from scipy.stats import spearmanr

#reference_dir = os.path.join('/app/input/', 'ref')
#prediction_dir = os.path.join('/app/input/', 'res')
#score_dir = '/app/output/'

# Default I/O directories:
root_dir = "~/ADMIRE/"

default_ref_dir = root_dir + "task_a/reference_data"
default_pred_dir = root_dir + "task_a/"
default_score_dir = root_dir


REF_COLS = ['compound', 'subset', 'sentence_type', 'expected_order']
SUB_COLS = ['compound', 'expected_order']


LENGTHS = {
    'en' : { 'train' : 70,
             'dev'   : 15,
             'test'  : 15
        },
    'xe' : { 'test' : 100},
    
    'pt' : { 'train' : 32,
             'dev'   : 10,
             'test'  : 13
        },
    'xp' : { 'test' : 55},
    }

NO_SCORE = {
    'acc_all'  : -999,
    'acc_lit'  : -999,
    'acc_id'   : -999,
    'dcg_all'  : -999,
    'dcg_lit'  : -999,
    'dcg_id'   : -999,
    'corr_all' : -999,
    'corr_lit' : -999,
    'corr_id'  : -999
}

NO_SCORES = {}
scores = {}

for l in LENGTHS.keys():
    NO_SCORES[l] = NO_SCORE
    scores[l] = NO_SCORE


SUBSETS = { 'train' : ['Train', 'Sample'],
            'dev'   : ['Dev'],
            'test'  : ['Test', 'Extended Evaluation']
    }


SUB_RE = re.compile("submission_([a-z][a-z])\.tsv",re.I)

# Weights for DCG scoring
DCG_WEIGHTS = [3,1,0,0,0]


def mkdir(d):
    if not os.path.exists(d):
        os.makedirs(d)


def write_scores(score_dict):
    
    
    print(" Languages present in score dictionary:")
    print(score_dict.keys())
    
    dump_dict = {}
    
    for lang in score_dict.keys():
        t_dict = { lk+'_'+lang : scores[lang][lk] for lk in scores[lang].keys() }
        dump_dict.update(t_dict)
    
    with open(os.path.join(score_dir, 'scores.json'), 'w') as score_file:
        score_file.write(json.dumps(dump_dict))


def top_1(inlist):
    return inlist[0]


def score_corr(inrow):
    res = spearmanr(np.array(inrow.expected_order,dtype='object'), np.array(inrow.predicted_order,dtype='object'))
    return res[0], res[1]


def score_dcg(inrow):
    
    ref = inrow.expected_order
    pred = inrow.predicted_order
    
    dcg = 0

    for (i,w) in enumerate(DCG_WEIGHTS):
        if w:
            dcg += w / log2(2+pred.index(ref[i]))

    return dcg


if __name__ == "__main__":
    
    stdout.write("Executing Task A scoring program\n")

    ## Arguments
    # 1 reference directory
    # 2 prediction directory
    # 3 score directory
    # 4 phase
    
    #### INPUT/OUTPUT: Get input and output directory names
    if len(argv) == 1:  # Use the default input and output directories, phase information if no arguments are provided
        reference_dir  =  default_ref_dir
        prediction_dir = default_pred_dir
        score_dir = default_score_dir
        
        phase = 'test'
        #lang  = 'en'
    else:
        reference_dir = argv[1]
        prediction_dir = argv[2]
        score_dir = argv[3]
        
        phase = argv[4]
        #lang  = argv[5]
        
    # Create the output directory, if it does not already exist
    mkdir(score_dir)
    
    
    # Detect submitted languages
    print(" Processing submitted files")
    
    all_sub_files = os.listdir(prediction_dir)
    sub_files = []
    
    
    for f in all_sub_files:
        r = SUB_RE.match(f)
        
        if r:
            sub_files.append((f,str.lower(r.group(1))))
    
    
    # If none to process, generate error and score nothing
    if len(sub_files) == 0:
        print(" Submission error: no valid submission files found. Please ensure submitted files are named like 'submission_XX.tsv' where XX is a 2-letter language code.")
        write_scores(NO_SCORES)
        exit(2)


    for (subfile, lang) in sub_files:        
        # If lang not in the keys of LENGTHS then write warning (but process others)
        if lang not in LENGTHS.keys():
            print(" Submission warning: submission file {} found for unsupported language {}. Not processed.".format(f,lang.upper()))
            print(" If you believe this warning has been generated in error, please contact the task organisers.")
            continue
        
    
        # Derive expected file information
        EXPECTED_LEN  = LENGTHS[lang][phase]
        EXPECTED_SUBS = SUBSETS[phase]
    
        print("Scoring submission for AdMIRe Subtask A; language: {}, {} phase".format(lang.upper(),phase))
    
    
        print(' Reading reference data')
        ref_data = pd.read_csv(os.path.join(reference_dir, "a_{}_{}_targets.tsv".format(lang,phase)), sep='\t',converters={"expected_order": literal_eval})
        
        
        # Reference data checks        
        ref_errs = []
        
        #  Required columns present
        if all(i in ref_data.columns for i in REF_COLS):
            pass
        else:
            ref_errs += ['C']
            
        #  No. of observations
        if len(ref_data) == EXPECTED_LEN:
            pass
        else:
            ref_errs += ['L']
            
        #  Expected subsets
        if min(ref_data['subset'].isin(EXPECTED_SUBS)):
            pass
        else:
            ref_errs += ['S']
            
            
        if len(ref_errs):
            if 'C' in ref_errs:
                print(" Reference data error: missing required columns")
            if 'L' in ref_errs:
                print(" Reference data error: unexpected length (got {}, expected {})".format(len(ref_data),EXPECTED_LEN))
            if 'S' in ref_errs:
                print(" Reference data error: unexpected subset value(s)")
                
            print("Please contact the organisers and let them know which subtask, language and phase generated this error.")
            write_scores(NO_SCORES)
            exit(1)
        
        
        print(' Reading submission data')
        sub_data = pd.read_csv(os.path.join(prediction_dir, subfile), sep='\t',converters={"expected_order": literal_eval})
        
        # Submission data checks 
        sub_errs = []
        
        #  Required columns present
        if all(i in sub_data.columns for i in SUB_COLS):
            pass
        else:
            sub_errs += ['C']
            
        #  No. of observations
        if len(sub_data) == EXPECTED_LEN:
            pass
        else:
            sub_errs += ['L']
            
        #  Lengths of predicted orders
        sub_lengths = sub_data['expected_order'].apply(len)
        
        if min(sub_lengths) == 5:
            pass
        else:
            sub_errs += ['O']
        
        if max(sub_lengths) == 5:
            pass
        else:
            sub_errs += ['O']
            
            
        if len(sub_errs):
            if 'C' in sub_errs:
                print(" Submission data error in {}: missing required columns".format(subfile))
                print(" Please ensure that the following columns are present:")
                print(SUB_COLS)
            if 'L' in sub_errs:
                print(" Submission data error: unexpected length (got {}, expected {})".format(len(sub_data),EXPECTED_LEN))
            if 'O' in sub_errs:
                print(" Submission data error: lengths of predictions (expected_order) must be 5.")
                
            print("Please review the submitted data and resubmit. If you are unable to resolve this issue, please contact the task organisers.")
            write_scores(NO_SCORES)
            exit(2)
    
    
        sub_data = sub_data.rename(columns={'expected_order':'predicted_order'})
        
        
        ref_data['top1_ref'] = ref_data['expected_order'].apply(top_1)
        sub_data['top1_sub'] = sub_data['predicted_order'].apply(top_1)
    
    
    
        try:
            merged = ref_data[REF_COLS+['top1_ref']].set_index('compound').join(sub_data[['compound','predicted_order', 'top1_sub']].set_index('compound'))
        except:
            print( "Error when joining submission to reference data. Please check submission file format.")
            # Score zeroes
            write_scores(NO_SCORES)
            exit(3)
    
    
        # Merged check - ensure target column fully populated
        if merged['predicted_order'].all():
            pass
        else:
            print( "Prediction column (expected_order) does not appear to be fully populated. Please review.")
            # Score zeroes
            write_scores(NO_SCORES)
            exit(3)
    
    
    
        merged[['correlation','corr_p']] = merged.apply(lambda row: score_corr(row),axis=1,result_type='expand')
        merged['dcg'] = merged.apply(lambda row: score_dcg(row),axis=1)
        
        
        merged_lit = merged[merged.sentence_type == 'literal']
        merged_id = merged[merged.sentence_type == 'idiomatic']
        
        
        print(' Checking top 1 accuracy')
        acc_all = accuracy_score(merged.top1_ref, merged.top1_sub)
        acc_lit = accuracy_score(merged_lit.top1_ref, merged_lit.top1_sub)
        acc_id = accuracy_score(merged_id.top1_ref, merged_id.top1_sub)
        
        
        print(' Checking rank correlation')
        corr_all = np.mean(merged.correlation)
        corr_lit = np.mean(merged_lit.correlation)
        corr_id  = np.mean(merged_id.correlation)
        
        print(' Checking DCG scores')
        dcg_all = np.mean(merged.dcg)
        dcg_lit = np.mean(merged_lit.dcg)
        dcg_id  = np.mean(merged_id.dcg)
        
        
        scores[lang] = {
            'acc_all'  : acc_all,
            'acc_lit'  : acc_lit,
            'acc_id'   : acc_id,
            'corr_all' : corr_all,
            'corr_lit' : corr_lit,
            'corr_id'  : corr_id,
            'dcg_all'  : dcg_all,
            'dcg_lit'  : dcg_lit,
            'dcg_id'   : dcg_id,
        }
        
        
        print(" Scores for {}:".format(lang.upper()))
        print(scores[lang])
    
    
    #merged.to_csv(score_dir+'/dcg_scores.tsv',sep='\t')
    
    print('Writing scores.json')
    write_scores(scores)
    
    
    
    
