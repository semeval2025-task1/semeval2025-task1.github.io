import json
import os
import re
from sys import argv, exit, stdout
import pandas as pd
import numpy as np
from sklearn.metrics import accuracy_score



# Default I/O directories:
root_dir = "/home/tom/Projects/Other Projects/ADMIRE/CodaBench/Tasks/"

default_ref_dir = root_dir + "task_b/reference_data"
default_pred_dir = root_dir + "task_b/"
default_score_dir = root_dir


REF_COLS = ['compound', 'subset', 'sentence_type', 'expected_item']
SUB_COLS = ['compound', 'sentence_type', 'expected_item']


LENGTHS = {
    'en' : { 'train' : 20,
             'dev'   : 5,
             'test'  : 5
        },
    'xe' : { 'test' : 30 },
    }

NO_SCORE = {
    'item_all'  : -999,
    'item_lit'  : -999,
    'item_id'   : -999,
    'sent_all' : -999,
    'sent_lit' : -999,
    'sent_id'  : -999
}

NO_SCORES = {}
scores = {}

for l in LENGTHS.keys():
    NO_SCORES[l] = NO_SCORE
    scores[l] = NO_SCORE


SUBSETS = { 'train' : ['Train', 'Sample'],
            'dev'   : ['Dev'],
            'test'  : ['Test', 'Extended Evaluation']
    }


SUB_RE = re.compile("submission_([a-z][a-z])\.tsv",re.I)



def mkdir(d):
    if not os.path.exists(d):
        os.makedirs(d)


def write_scores(score_dict):
    
    
    print(" Languages present in score dictionary:")
    print(score_dict.keys())
    
    dump_dict = {}
    
    for lang in score_dict.keys():
        t_dict = { lk+'_'+lang : scores[lang][lk] for lk in scores[lang].keys() }
        dump_dict.update(t_dict)
    
    with open(os.path.join(score_dir, 'scores.json'), 'w') as score_file:
        score_file.write(json.dumps(dump_dict))




if __name__ == "__main__":
    
    stdout.write("Executing Task B scoring program\n")

    ## Arguments
    # 1 reference directory
    # 2 prediction directory
    # 3 score directory
    # 4 phase
    
    #### INPUT/OUTPUT: Get input and output directory names
    if len(argv) == 1:  # Use the default input and output directories, phase information if no arguments are provided
        reference_dir  =  default_ref_dir
        prediction_dir = default_pred_dir
        score_dir = default_score_dir
        
        phase = 'train'
        #lang  = 'en'
    else:
        reference_dir = argv[1]
        prediction_dir = argv[2]
        score_dir = argv[3]
        
        phase = argv[4]
        #lang  = argv[5]
        
    # Create the output directory, if it does not already exist
    mkdir(score_dir)
    
    
    # Detect submitted languages
    print(" Processing submitted files")
    
    all_sub_files = os.listdir(prediction_dir)
    sub_files = []
    
    
    for f in all_sub_files:
        r = SUB_RE.match(f)
        
        if r:
            sub_files.append((f,str.lower(r.group(1))))
    
    
    # If none to process, generate error and score nothing
    if len(sub_files) == 0:
        print(" Submission error: no valid submission files found. Please ensure submitted files are named like 'submission_XX.tsv' where XX is a 2-letter language code.")
        write_scores(NO_SCORES)
        exit(2)


    for (subfile, lang) in sub_files:        
        # If lang not in the keys of LENGTHS then write warning (but process others)
        if lang not in LENGTHS.keys():
            print(" Submission warning: submission file {} found for unsupported language {}. Not processed.".format(f,lang.upper()))
            print(" If you believe this warning has been generated in error, please contact the task organisers.")
            continue
        
    
        # Derive expected file information
        EXPECTED_LEN  = LENGTHS[lang][phase]
        EXPECTED_SUBS = SUBSETS[phase]
    
        print("Scoring submission for AdMIRe Subtask B; language: {}, {} phase".format(lang.upper(),phase))
    
    
        print(' Reading reference data')
        ref_data = pd.read_csv(os.path.join(reference_dir, "b_{}_{}_targets.tsv".format(lang,phase)), sep='\t')
        
        
        # Reference data checks        
        ref_errs = []
        
        #  Required columns present
        if all(i in ref_data.columns for i in REF_COLS):
            pass
        else:
            ref_errs += ['C']
            
        #  No. of observations
        if len(ref_data) == EXPECTED_LEN:
            pass
        else:
            ref_errs += ['L']
            
        #  Expected subsets
        if min(ref_data['subset'].isin(EXPECTED_SUBS)):
            pass
        else:
            ref_errs += ['S']
            
            
        if len(ref_errs):
            if 'C' in ref_errs:
                print(" Reference data error: missing required columns")
            if 'L' in ref_errs:
                print(" Reference data error: unexpected length (got {}, expected {})".format(len(ref_data),EXPECTED_LEN))
            if 'S' in ref_errs:
                print(" Reference data error: unexpected subset value(s)")
                
            print("Please contact the organisers and let them know which subtask, language and phase generated this error.")
            write_scores(NO_SCORES)
            exit(1)
        
        
        print(' Reading submission data')
        sub_data = pd.read_csv(os.path.join(prediction_dir, subfile), sep='\t')
        
        # Submission data checks 
        sub_errs = []
        
        #  Required columns present
        if all(i in sub_data.columns for i in SUB_COLS):
            pass
        else:
            sub_errs += ['C']
            
        #  No. of observations
        if len(sub_data) == EXPECTED_LEN:
            pass
        else:
            sub_errs += ['L']
            
            
            
        if len(sub_errs):
            if 'C' in sub_errs:
                print(" Submission data error in {}: missing required columns".format(subfile))
                print(" Please ensure that the following columns are present:")
                print(SUB_COLS)
            if 'L' in sub_errs:
                print(" Submission data error: unexpected length (got {}, expected {})".format(len(sub_data),EXPECTED_LEN))
            if 'O' in sub_errs:
                print(" Submission data error: lengths of predictions (expected_order) must be 5.")
                
            print("Please review the submitted data and resubmit. If you are unable to resolve this issue, please contact the task organisers.")
            write_scores(NO_SCORES)
            exit(2)
    
    
        sub_data = sub_data.rename(columns={'expected_item':'predicted_item',
                                            'sentence_type':'predicted_type'})
        
    
        try:
            merged = ref_data[REF_COLS].set_index('compound').join(sub_data[['compound','predicted_item', 'predicted_type']].set_index('compound'))
        except:
            print( "Error when joining submission to reference data. Please check submission file format.")
            # Score zeroes
            write_scores(NO_SCORES)
            exit(3)
    
    
        # Merged check - ensure target column fully populated
        if merged['predicted_item'].all():
            pass
        else:
            print( "Prediction column (expected_item) does not appear to be fully populated. Please review.")
            # Score zeroes
            write_scores(NO_SCORES)
            exit(3)
    
        
        
        merged_lit = merged[merged.sentence_type == 'literal']
        merged_id = merged[merged.sentence_type == 'idiomatic']
        
        
        print(' Checking item accuracy')
        item_all = accuracy_score(merged.expected_item, merged.predicted_item)
        item_lit = accuracy_score(merged_lit.expected_item, merged_lit.predicted_item)
        item_id = accuracy_score(merged_id.expected_item, merged_id.predicted_item)
        
        
        print(' Checking idiomaticity detection (sentence type) accuracy')
        sent_all = accuracy_score(merged.sentence_type, merged.predicted_type)
        sent_lit = accuracy_score(merged_lit.sentence_type, merged_lit.predicted_type)
        sent_id = accuracy_score(merged_id.sentence_type, merged_id.predicted_type)
        
        
        
        scores[lang] = {
            'item_all'  : item_all,
            'item_lit'  : item_lit,
            'item_id'   : item_id,
            'sent_all' : sent_all,
            'sent_lit' : sent_lit,
            'sent_id'  : sent_id
        }
        
        
        print(" Scores for {}:".format(lang.upper()))
        print(scores[lang])
    
    
    print('Writing scores.json')
    write_scores(scores)
